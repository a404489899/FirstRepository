/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author jin.zhu
 */
public class SHAEncoderUtils {
    @Inject
    private Logger logger;
    public String  encodePassword(String orPassword){
        String returnValue = "";
        try{
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] encodePassword = md.digest(orPassword.getBytes());
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < encodePassword.length; i++){
            String tmp = Integer.toHexString(encodePassword[i] & 0xff);
            if(tmp.length() == 1){
                builder.append(0).append(tmp);
            }else{
                builder.append(tmp);
            } 
        }
        returnValue = builder.toString();
        }catch(NoSuchAlgorithmException ex){
            logger.log(Level.SEVERE, "パスワード変換に失敗しました", ex);
        }
        return returnValue;
    }
}
