/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.cdis;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import jp.co.test.entities.Texttable;
import jp.co.text.ejbs.UserManager;

/**
 *
 * @author jin.zhu
 */
@Named(value = "makeText")
@RequestScoped
public class MakeText {
    
    private String text;
    private String userName;
    private String title;
    private static final String  file_name = "C:\\dev\\";
    
    @EJB
    private UserManager userManager;
    @Inject 
    private Logger log;
    
    @Inject
    DataSource source;
    /**
     * Creates a new instance of MakeText
     */
    public MakeText() {
    }
    public String saveText(){
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext externalContext = context.getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        
            this.userName = request.getUserPrincipal().getName();
            this.title = getTitle();
            LocalDateTime datetime = LocalDateTime.now();
            if(Objects.isNull(title)){
                title = datetime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
                System.out.println("デフォルトファイル名の出力="+title);
            }
        try{
            String fileName = file_name + title + ".txt";
            System.out.println(fileName);
            File file = new File(fileName);
            
            if(!file.exists()){
                file.createNewFile();
            }
            //画面で入力した内容をファイルに保存
      
            FileOutputStream fos = new FileOutputStream(file);
            BufferedWriter bfw = new BufferedWriter(new OutputStreamWriter(fos, Charset.forName("UTF-8")));
            System.out.println(getText());
            bfw.write(getText());
            bfw.close();
            //テーブルへの書き込み準備
            Texttable texttable = new Texttable();
            texttable.setFileName(file.getName());
            texttable.setFileSize(file.length());
   
            
            texttable.setUserName(userName);
            texttable.setCreateDate(Date.from(datetime.atZone(ZoneId.systemDefault()).toInstant()));
            setBlob(texttable, file);
        }
        catch(FileNotFoundException ef){
            log.log(Level.SEVERE, "ファイルの作成に失敗しました", ef);
        }
        catch(IOException ioe){
            log.log(Level.SEVERE, "ファイル書き込みに失敗しました", ioe);
        }
        catch(Exception ex){
            log.log(Level.SEVERE, "テキストの保存に失敗しました", ex);
            return "";
        }
        return "/user/home?faces-redirect=true";
    }
    
    public void setBlob(Texttable texttable ,File file) {
        try{
            Connection con = source.getConnection();
            PreparedStatement ps = con.prepareStatement("Insert into APP.texttable values(?,?,?,?,?)");
            ps.setString(1, texttable.getFileName());
            ps.setLong(2,file.length());
            ps.setDate(3, new java.sql.Date(texttable.getCreateDate().getTime()));
            ps.setBinaryStream(4, new FileInputStream(file));
            ps.setString(5, texttable.getUserName());
            ps.executeUpdate();
            ps.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
       
    }
    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
}
