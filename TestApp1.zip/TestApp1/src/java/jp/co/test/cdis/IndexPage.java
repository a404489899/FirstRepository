/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.cdis;

import java.io.IOException;
import java.security.Principal;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jin.zhu
 */
@Named(value = "indexPage")
@RequestScoped
public class IndexPage {

    /**
     * Creates a new instance of IndexPage
     */
        
    private String userName;
    private String password;
    
    public IndexPage() {
    }
    
    public String login(){
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext externalContext = context.getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        try{
            System.out.println("ログイン認証");
            request.login(getUserName(), getPassword());
        }catch(ServletException ex){
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"ログインに失敗しました。",
                                "ユーザ、パスワードを正しく入力してください。"));
            return "";
        }
        return "/user/home?faces-redirect=true";
        
    }
    public String logOut(){
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext externalContext = context.getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        try{
            request.logout();
        }catch(ServletException ex){
             Logger.getLogger(IndexPage.class.getName()).log(Level.SEVERE, "ログアウト失敗", ex);
            return "";
        }
        return "/faces/index?faces-redirect=true";
    }
    public void pageOnLoad(){
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext externalContext = context.getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        Principal principal = request.getUserPrincipal();
        
        //ログイン済みである場合
        if(principal != null){
            try{
                StringBuilder redirectURL = new StringBuilder(request.getContextPath());
                redirectURL.append("faces/user/home");
                FacesContext.getCurrentInstance().getExternalContext().redirect(redirectURL.toString());
            }catch(IOException e){
                Logger.getLogger(IndexPage.class.getName()).log(Level.SEVERE,"ログアウトに失敗しました",e);
            }
        }
    }
    /**
     * @return the userName
     */
    public String getUserName(){
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
   
}
