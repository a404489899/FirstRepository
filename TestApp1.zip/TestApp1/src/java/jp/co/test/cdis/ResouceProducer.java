/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.cdis;

import java.util.logging.Logger;
import javax.sql.DataSource;
import javax.annotation.Resource;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jin.zhu
 */
@Dependent
public class ResouceProducer {

    /**
     * Creates a new instance of ResouceProducer
     */
    @Produces
    @PersistenceContext
    private EntityManager em;  
    
    @Produces
    @Resource(lookup = "jdbc/sample")
    private DataSource sample;
    /**
     *
     * @param ip
     * @return
     */
    @Produces @Dependent
    public Logger getLogger(InjectionPoint ip){
        return Logger.getLogger(ip.getMember().getDeclaringClass().getPackage().getName());
    }
    
}
