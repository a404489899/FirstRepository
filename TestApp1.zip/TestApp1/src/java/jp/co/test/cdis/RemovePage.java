/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.cdis;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import jp.co.text.ejbs.UserManager;

/**
 *
 * @author jin.zhu
 */
@Named(value = "removePage")
@RequestScoped
public class RemovePage {

    /**
     * Creates a new instance of RemovePage
     */
    private String userName;
    @EJB
    private UserManager userManager;
    
    public RemovePage() {
    }
    
    public String removeUser(){
        try{
            userManager.removeUser(this.getUserName());
        }catch(Exception e){
            e.printStackTrace();
            return "/faces/login/error?faces-redirect=true";
        }
        return "rem-success?faces-redirect=true";
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
}
