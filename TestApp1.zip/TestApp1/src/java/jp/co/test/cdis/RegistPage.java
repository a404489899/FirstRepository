/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.cdis;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import jp.co.text.ejbs.UserManager;

/**
 *
 * @author jin.zhu
 */
@Named(value = "registPage")
@RequestScoped
public class RegistPage {

    /**
     * Creates a new instance of RegistPage
     */
    private String userName;
    private String mailaddress;
    private String password;
    private String groupName;
    
    @EJB
    UserManager userManager;
    
    public RegistPage() {
    }
    
    public String addUser(){
        userManager.addUser(userName, mailaddress, password, groupName);
        
        return "reg-success";
    }
    
    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the mailaddress
     */
    public String getMailaddress() {
        return mailaddress;
    }

    /**
     * @param mailaddress the mailaddress to set
     */
    public void setMailaddress(String mailaddress) {
        this.mailaddress = mailaddress;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the groupName
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * @param groupName the groupName to set
     */
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    
}
