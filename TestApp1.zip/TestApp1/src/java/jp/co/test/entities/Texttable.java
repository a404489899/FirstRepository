/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.test.entities;

import java.io.Serializable;
import java.sql.Blob;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jin.zhu
 */
@Entity
@Table(name = "TEXTTABLE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Texttable.findAll", query = "SELECT t FROM Texttable t")
    , @NamedQuery(name = "Texttable.findByFileName", query = "SELECT t FROM Texttable t WHERE t.fileName = :fileName")
    , @NamedQuery(name = "Texttable.findByFileSize", query = "SELECT t FROM Texttable t WHERE t.fileSize = :fileSize")
    , @NamedQuery(name = "Texttable.findByCreateDate", query = "SELECT t FROM Texttable t WHERE t.createDate = :createDate")
    , @NamedQuery(name = "Texttable.findByUserName", query = "SELECT t FROM Texttable t WHERE t.userName = :userName")})
public class Texttable implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 128)
    @Column(name = "FILE_NAME")
    private String fileName;
    @Column(name = "FILE_SIZE")
    private Long fileSize;
    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Lob
    @Column(name = "MEMO")
    @Basic(fetch =FetchType.LAZY)
    private Blob memo;
    @Size(max = 128)
    @Column(name = "USER_NAME")
    private String userName;

    public Texttable() {
    }

    public Texttable(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Blob getMemo() {
        return memo;
    }

    public void setMemo(Blob memo) {
        this.memo = memo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (fileName != null ? fileName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Texttable)) {
            return false;
        }
        Texttable other = (Texttable) object;
        if ((this.fileName == null && other.fileName != null) || (this.fileName != null && !this.fileName.equals(other.fileName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jp.co.test.entities.Texttable[ fileName=" + fileName + " ]";
    }
    
}
