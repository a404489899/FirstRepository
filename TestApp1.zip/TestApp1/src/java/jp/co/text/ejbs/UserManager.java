/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.text.ejbs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.sql.DataSource;
import jp.co.test.entities.Grouptable;
import jp.co.test.entities.GrouptablePK;
import jp.co.test.entities.Texttable;

import jp.co.test.entities.Usertable;
import jp.co.test.utils.SHAEncoderUtils;

/**
 *
 * @author jin.zhu
 */
@Stateless
public class UserManager {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Inject
    EntityManager em;
    
    @Inject
    Logger log;
    
    @Inject
    DataSource source;
    
    public void addUser(String userName,String mailaddress,String password,String groupName){
        
        Usertable user = new Usertable();
        user.setUsername(userName);
        user.setMailaddress(mailaddress);
        SHAEncoderUtils encoder = new SHAEncoderUtils();
        String encodePassword = encoder.encodePassword(password);
        user.setPassword(encodePassword);
        
        Grouptable group = new Grouptable();
        group.setGrouptablePK(new GrouptablePK(userName,groupName));
        group.setUsertable(user);
        
        //em.getTransaction().begin();
        em.persist(user);
        em.persist(group);
        System.out.println("ユーザ登録完了");
        //em.getTransaction().commit();
    }
    
     /**
     * 指定ユーザの検索
     * @param username
     * @return 
     */
    public Usertable findUser(String username){
        Usertable user = em.find(Usertable.class, username);
        
        return user;
    
    }
    
    /**
     * 指定ユーザの削除
     * @param username
     */
    public void removeUser(String username){
        Usertable user = em.find(Usertable.class, username);
        em.remove(user);
    }
    
     public void createText(Texttable texttable ,File file) throws SQLException {
            Connection con = source.getConnection();
            try (PreparedStatement ps = con.prepareStatement("Insert into APP.texttable values(?,?,?,?,?)")) {
                ps.setString(1, texttable.getFileName());
                ps.setLong(2,file.length());
                ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                ps.setBinaryStream(4, new FileInputStream(file));
                ps.setString(5, texttable.getUserName());
                ps.executeUpdate();
            }
            
        catch(FileNotFoundException | SQLException e){
            log.log(Level.SEVERE, "テーブル書き込みに失敗しました。", e);
        }
       
    }
    public String getMemo(String userName) throws SQLException {
        Connection con = source.getConnection();
        Statement stmt = con.createStatement();
        String sql = "select * from APP.texttable where user_name = ?";
        ResultSet rset = stmt.executeQuery(sql);
        Blob blob = null;
        System.out.println(rset.getRow());
        while(rset.next()){
            blob = rset.getBlob("memo");
            
        }
        byte [] buffer = blob.getBytes(1, (int)blob.length());
        String result = Arrays.toString(buffer);
        return result;
    }
}
