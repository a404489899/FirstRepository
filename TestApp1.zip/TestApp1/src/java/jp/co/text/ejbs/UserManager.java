/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.text.ejbs;

import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import jp.co.test.entities.Grouptable;
import jp.co.test.entities.GrouptablePK;
import jp.co.test.entities.Texttable;

import jp.co.test.entities.Usertable;
import jp.co.test.utils.SHAEncoderUtils;

/**
 *
 * @author jin.zhu
 */
@Stateless
public class UserManager {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Inject
    EntityManager em;
    
    @Inject
    Logger log;
    
    public void addUser(String userName,String mailaddress,String password,String groupName){
        
        Usertable user = new Usertable();
        user.setUsername(userName);
        user.setMailaddress(mailaddress);
        SHAEncoderUtils encoder = new SHAEncoderUtils();
        String encodePassword = encoder.encodePassword(password);
        user.setPassword(encodePassword);
        
        Grouptable group = new Grouptable();
        group.setGrouptablePK(new GrouptablePK(userName,groupName));
        group.setUsertable(user);
        
        //em.getTransaction().begin();
        em.persist(user);
        em.persist(group);
        System.out.println("ユーザ登録完了");
        //em.getTransaction().commit();
    }
    
     /**
     * 指定ユーザの検索
     * @param username
     * @return 
     */
    public Usertable findUser(String username){
        Usertable user = em.find(Usertable.class, username);
        
        return user;
    
    }
    
    /**
     * 指定ユーザの削除
     * @param username
     */
    public void removeUser(String username){
        Usertable user = em.find(Usertable.class, username);
        em.remove(user);
    }
    
    public void addText(Texttable texttable){
        em.persist(texttable);
    }
}
